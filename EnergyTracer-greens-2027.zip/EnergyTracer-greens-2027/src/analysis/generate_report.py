"""
Report generation module for energy measurement comparisons.

Produces a concise, GitHub PR-ready report comparing
energy consumption between two code variants (with / without a code smell).
The output format depends on the DocWriter implementation provided.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .utils.doc_writer import DocWriter
from .utils.get_hardware_details import get_hardware_details

if TYPE_CHECKING:
    import pandas as pd

    from .utils.doc_writer import DocWriter


from .statistical_analysis import (
    ALPHA,
    METRICS,
    effect_size_label,
    mann_whitney_u_test,
    median_and_iqr,
    remove_outliers_zscore,
    shapiro_wilk_test,
    vargha_delaney_a,
)


def _fmt_pvalue(p: float) -> str:
    """Format a p-value: scientific notation when < 0.001, else 4 decimals."""
    if p < 0.001:
        return f"{p:.2e}"
    return f"{p:.4f}"

def _metric_unit(metric: str, display_metric: str) -> str:
    """Return the display unit for a metric (e.g. "mJ", "s", "mg CO2eq")."""
    if metric == "time_s":
        return "s"
    if display_metric == "co2_eq":
        return "mg CO2eq"

    return "mJ"


def generate_pr_report(
    doc_writer: DocWriter,
    df_with: pd.DataFrame,
    df_without: pd.DataFrame,
    profiler: str,
    data_type: str,
    verbose: bool = False,
) -> str:
    """
    Generate a concise report suitable for a GitHub PR description.

    The report compares energy consumption between code with and without a
    code smell to justify whether removing the smell has a measurable
    energy impact. The output format depends on the DocWriter implementation.

    Inputs
    ------
        doc_writer: A DocWriter implementation controlling the output format.
        df_with: DataFrame of measurements *with* the code smell.
        df_without: DataFrame of measurements *without* the code smell.
        profiler: Profiler name (e.g. "mac-silicon", "carbon").
        data_type: "cleaned" or "raw".
        verbose: Whether to log additional details.

    Returns
    -------
        A formatted string produced by the writer.
    """
    significant_rows: list[list[str]] = []
    median_rows: list[list[str]] = []
    normality_rows: list[list[str]] = []
    normal_count = 0
    non_normal_count = 0
    undefined_metrics: list[str] = []
    verdicts: list[str] = []

    for metric in METRICS:
        if metric not in df_with.columns or metric not in df_without.columns:
            continue

        vals_with = remove_outliers_zscore(df_with[metric].dropna().tolist())
        vals_without = remove_outliers_zscore(df_without[metric].dropna().tolist())

        if len(vals_with) < 2 or len(vals_without) < 2:
            continue

        median_with, iqr_with = median_and_iqr(vals_with)
        median_without, iqr_without = median_and_iqr(vals_without)

        delta = (
            (median_with - median_without) / median_with * 100
            if median_with != 0
            else float("nan")
        )

        _, p_val, significant = mann_whitney_u_test(vals_with, vals_without)
        a = vargha_delaney_a(vals_with, vals_without)
        effect = effect_size_label(a)

        display_metric = (
            "co2_eq" if (profiler == "carbon" and metric == "ane_mj") else metric
        )
        if np.isnan(p_val):
            undefined_metrics.append(doc_writer.get_inline_code(display_metric))

        # Shapiro-Wilk normality is checked on the same cleaned samples fed to
        # Mann-Whitney U / Vargha-Delaney A, for every metric, so all results can
        # be read together regardless of whether the difference is significant.
        for group, values in (("With smell", vals_with), ("Without smell", vals_without)):
            if len(values) < 3:
                continue

            shapiro_stat, shapiro_p, is_normal = shapiro_wilk_test(values)
            if not np.isfinite(shapiro_p):
                continue

            if is_normal:
                normal_count += 1
                result = "Not rejected"
            else:
                non_normal_count += 1
                result = "Rejected"

            normality_rows.append(
                [
                    doc_writer.get_inline_code(display_metric),
                    group,
                    str(len(values)),
                    f"{shapiro_stat:.4f}",
                    _fmt_pvalue(shapiro_p),
                    result,
                ]
            )

        # Descriptive values are reported for every analysed metric, independently
        # of statistical significance, so the full picture is always visible.
        unit = _metric_unit(metric, display_metric)
        median_rows.append(
            [
                doc_writer.get_inline_code(display_metric),
                f"{median_with:.3f} {unit}",
                f"{iqr_with:.3f} {unit}",
                f"{median_without:.3f} {unit}",
                f"{iqr_without:.3f} {unit}",
            ]
        )

        if not significant:
            continue

        delta_str = f"{delta:+.2f}%" if not np.isnan(delta) else "N/A"

        significant_rows.append(
            [
                doc_writer.get_inline_code(display_metric),
                delta_str,
                _fmt_pvalue(p_val),
                f"{a:.3f}",
                effect,
                "\u2705",
            ]
        )

        if effect != "negligible":
            direction = "lower" if median_without < median_with else "higher"
            metric_type = "time" if metric == "time_s" else "energy"
            if median_without == median_with:
                change = "no change in median"
            else:
                percentage = f"{abs(delta):.1f}% " if np.isfinite(delta) else ""
                change = f"{percentage}{direction} median"
            verdicts.append(
                f"{doc_writer.get_bold(doc_writer.get_inline_code(display_metric))}: "
                f"{change} {metric_type} "
                f"(Vargha-Delaney A\u2009=\u2009{a:.3f}, {effect})"
            )

    # ── Title & context ───────────────────────────────────
    doc_writer.add_h2(
        f"Energy Report \u2014 {doc_writer.get_inline_code(profiler)} ({data_type})"
    )
    doc_writer.add_quote(
        f"{len(df_with)} samples (with smell) vs "
        f"{len(df_without)} samples (without smell) \u2014 "
        f"\u03b1\u2009=\u2009{ALPHA}"
    )

    # ── Instance info ─────────────────────────────────────
    doc_writer.add_h3("Instance Info")
    doc_writer.add_list(
        [
            f"{doc_writer.get_bold(key)}: {doc_writer.get_inline_code(value)}"
            for key, value in get_hardware_details().items()
        ]
    )

    # ── Totals ──────────────────────────────────────────────
    energy_cols = ["cpu_mj", "gpu_mj", "dram_mj"]
    if profiler == "mac":
        energy_cols.append("ane_mj")

    total_j_with = 0.0
    total_j_without = 0.0

    for col in energy_cols:
        if col in df_with.columns:
            total_j_with += (
                sum(remove_outliers_zscore(df_with[col].dropna().tolist())) / 1000
            )
        if col in df_without.columns:
            total_j_without += (
                sum(remove_outliers_zscore(df_without[col].dropna().tolist())) / 1000
            )

    if total_j_with > 0 and total_j_without > 0:
        doc_writer.add_h3("Global Consumption")

        table_head = [["Metric", "With smell", "Without smell"]]
        table_rows: list[list[str]] = []

        times_with = (
            remove_outliers_zscore(df_with["time_s"].dropna().tolist())
            if "time_s" in df_with.columns
            else []
        )
        times_without = (
            remove_outliers_zscore(df_without["time_s"].dropna().tolist())
            if "time_s" in df_without.columns
            else []
        )
        total_s_with = sum(times_with)
        total_s_without = sum(times_without)

        if total_s_with > 0 and total_s_without > 0:
            median_ms_with = float(np.median(times_with)) * 1000
            median_ms_without = float(np.median(times_without)) * 1000
            table_rows.append(
                [
                    doc_writer.get_bold("Median Execution Time"),
                    f"{median_ms_with:.2f} ms",
                    f"{median_ms_without:.2f} ms",
                ]
            )

            avg_w_with = total_j_with / total_s_with
            avg_w_without = total_j_without / total_s_without
            table_rows.append(
                [
                    doc_writer.get_bold("Average Power"),
                    f"{avg_w_with:.3f} W",
                    f"{avg_w_without:.3f} W",
                ]
            )

        table_rows.append(
            [
                doc_writer.get_bold("Total Energy"),
                f"{total_j_with:.2f} J",
                f"{total_j_without:.2f} J",
            ]
        )

        doc_writer.add_table(table_head, table_rows)

    doc_writer.add_newline()
    doc_writer.add_quote(
        "The total energy is the sum of measurements across all iterations, "
        "converted to joules (J). If you ran the ./run_experiment.sh script, "
        "this reflects the cumulative energy of all 30 iterations of the process."
    )

    # ── Descriptive values (always shown, regardless of significance) ───
    doc_writer.add_h3("Median Values and IQR")
    if median_rows:
        median_head = [[
            "Metric",
            "Median (with smell)",
            "IQR (with smell)",
            "Median (without smell)",
            "IQR (without smell)",
        ]]
        doc_writer.add_table(median_head, median_rows)
        doc_writer.add_quote(
            "IQR = 75th percentile \u2212 25th percentile (linear interpolation)."
        )
    else:
        doc_writer.add_paragraph(
            "No metrics had enough samples to compute medians and IQRs."
        )

    # ── Normality (descriptive; does not gate the rank-based test) ────────────
    doc_writer.add_h3("Normality (Shapiro-Wilk)")
    tested_count = normal_count + non_normal_count
    if tested_count:
        normality_rate = normal_count / tested_count * 100
        doc_writer.add_paragraph(
            f"Normality rate: {normality_rate:.1f}% "
            f"({normal_count} not rejected, {non_normal_count} rejected "
            f"out of {tested_count} tested distributions)."
        )
        doc_writer.add_table(
            [["Metric", "Group", "N", "W statistic", "p-value", "Result"]],
            normality_rows,
        )
        doc_writer.add_quote(
            f"At \u03b1\u2009=\u2009{ALPHA}, 'Not rejected' means Shapiro-Wilk found no "
            "evidence against normality (H\u2080: the sample is normally distributed); "
            "it does not prove the data are normal. These results do not change "
            "which test is applied below \u2014 use them to judge how much to trust "
            "the Mann-Whitney U / Vargha-Delaney A results for that metric."
        )
    else:
        doc_writer.add_paragraph(
            "No metric/group distributions had enough valid measurements "
            "to test normality."
        )

    doc_writer.add_h3("Statistical Analysis")

    if undefined_metrics:
        doc_writer.add_paragraph(
            "Mann-Whitney U test was undefined for: "
            + ", ".join(undefined_metrics)
            + "."
        )

    # ── Table (only if there are significant results) ─────
    if significant_rows:
        stats_head = [
            [
                "Metric",
                "\u0394 median",
                "p-value (Mann-Whitney U)",
                "Vargha-Delaney A",
                "Effect",
                "Sig.",
            ]
        ]
        doc_writer.add_table(stats_head, significant_rows)
        doc_writer.add_quote(
            "\u0394 median = (median_with \u2212 median_without) / median_with \u00d7 100. "
            "For a positive with-smell median, positive \u2192 it is higher. "
            "A = P(with-smell value > without-smell value) + 0.5 \u00d7 P(tie)."
        )
    elif median_rows and len(undefined_metrics) == len(median_rows):
        doc_writer.add_paragraph("No valid Mann-Whitney U tests could be calculated.")
    else:
        doc_writer.add_paragraph(
            "No statistically significant differences were found between the two variants."
        )

    # ── Verdict ───────────────────────────────────────────
    doc_writer.add_h3("Verdict")
    if verdicts:
        doc_writer.add_paragraph(
            "Removing the code smell leads to measurable energy differences:"
        )
        doc_writer.add_list(verdicts)
        doc_writer.add_newline()
        doc_writer.add_quote(
            "Verdict percentages describe the change relative to the with-smell median."
        )
    elif median_rows and len(undefined_metrics) == len(median_rows):
        doc_writer.add_paragraph(
            "No statistical verdict is available because the Mann-Whitney U tests "
            "were undefined."
        )
    else:
        doc_writer.add_paragraph(
            "The code smell does not measurably impact energy consumption "
            "under the tested conditions."
        )

    return doc_writer.build()
